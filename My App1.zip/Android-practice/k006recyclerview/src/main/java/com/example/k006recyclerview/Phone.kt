package com.example.k006recyclerview

data class Phone(val name : String, val company : String, val image : Int)